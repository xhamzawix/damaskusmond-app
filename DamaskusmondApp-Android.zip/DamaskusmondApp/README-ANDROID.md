# 📱 damaskusmond – Native Android App (Bestellannahme & Fahrer)

Diese App ist eine **echte native Android-App** (kein PWA-Ersatz), die:
- die bestehende Restaurant-/Fahrer-Weboberfläche in einer WebView anzeigt,
- bei neuer Bestellung / neuer Zuweisung einen **Vollbild-Alarm** auslöst — mit durchgehendem Ton und Vibration, der **über jeder anderen offenen App und sogar über dem Sperrbildschirm** erscheint (wie ein eingehender Anruf),
- über OneSignal Push-Benachrichtigungen empfängt (dieselbe OneSignal-Einrichtung, die bereits für die Web-Version verwendet wird).

---

## 1. Voraussetzungen

- **Android Studio** (kostenlos): https://developer.android.com/studio
- Ein Android-Testgerät oder Emulator (Android 8.0 / API 26 oder neuer)
- Der OneSignal **App ID**, den wir bereits im Web-Setup eingerichtet haben

---

## 2. Projekt öffnen

1. Android Studio öffnen → **„Open"** → den Ordner `DamaskusmondApp` auswählen
2. Warten, bis Gradle das Projekt automatisch synchronisiert (kann beim ersten Mal einige Minuten dauern, lädt Abhängigkeiten herunter)

---

## 3. OneSignal App ID eintragen (Pflichtschritt)

Datei öffnen:
```
app/src/main/java/com/damaskusmond/app/ApplicationClass.kt
```

Diese Zeile:
```kotlin
const val ONESIGNAL_APP_ID = "DEINE-ONESIGNAL-APP-ID-HIER"
```

durch die eigene App ID ersetzen (dieselbe, die bereits in `admin/settings-notifications.php` verwendet wird).

---

## 4. Wichtig: OneSignal für Android in der OneSignal-Konsole aktivieren

OneSignal benötigt für **Android-Push** zusätzlich eine Verbindung zu **Firebase Cloud Messaging (FCM)** – das ist ein separater, kostenloser Schritt direkt in der OneSignal-Konsole (auch wenn bereits Web Push eingerichtet ist):

1. In der OneSignal-Konsole → Settings → Platforms → **Google Android (FCM)**
2. Dort wird eine kurze Anleitung angezeigt, um ein kostenloses Firebase-Projekt zu verknüpfen (nur wenige Klicks, kein eigener Code nötig)
3. Speichern

Ohne diesen Schritt werden Android-Push-Benachrichtigungen nicht ankommen.

---

## 5. Basis-URL prüfen

Datei: `app/src/main/java/com/damaskusmond/app/MainActivity.kt`
```kotlin
private val baseUrl = "https://www.damaskusmond.com/orders"
```
Nur ändern, falls sich der Installationspfad der Web-App jemals ändert.

---

## 6. App bauen und installieren

**Zum Testen (per USB-Kabel verbundenes Gerät oder Emulator):**
1. Android-Gerät per USB verbinden, **USB-Debugging** in den Entwickleroptionen aktivieren
2. In Android Studio oben auf den grünen ▶ **Run**-Button klicken
3. Gerät auswählen → die App wird installiert und gestartet

**Fertige APK-Datei erstellen (zum Verteilen ohne Kabel):**
1. Menü: **Build → Generate Signed Bundle / APK**
2. **APK** auswählen → Weiter
3. Beim ersten Mal: **Create new...** um einen eigenen Signierschlüssel (Keystore) zu erstellen — Passwort und Speicherort merken, dieser wird für alle zukünftigen Updates der App gebraucht
4. **release** auswählen → Fertigstellen
5. Die fertige `.apk`-Datei liegt danach unter: `app/release/app-release.apk`
6. Diese Datei auf das Tablet/Handy kopieren (z. B. per USB, E-Mail, Google Drive) und dort antippen, um sie zu installieren
   - Beim ersten Mal muss eventuell **„Installation aus unbekannten Quellen erlauben"** bestätigt werden

---

## 7. Nach der Installation auf jedem Gerät

1. App öffnen → beim ersten Start: **Rolle wählen** (Restaurant/Küche oder Fahrer)
2. Benachrichtigungserlaubnis bestätigen, wenn gefragt
3. **Wichtig bei Android 13+ (Android 14 besonders):** Unter
   `Einstellungen → Apps → damaskusmond → Benachrichtigungen → Vollbildbenachrichtigungen`
   sicherstellen, dass diese Berechtigung **erlaubt** ist — manche Android-Versionen fragen separat danach oder verlangen eine manuelle Bestätigung, da „Vollbild-Alarme" eine sensible Berechtigung sind (ähnlich wie bei Wecker- oder Anruf-Apps)
4. Fertig — die App bleibt im Hintergrund aktiv und zeigt bei neuer Bestellung den Vollbild-Alarm, auch wenn eine andere App geöffnet ist

---

## 8. Wie die Vollbild-Alarme funktionieren (technischer Überblick)

- Bei bezahlter Bestellung sendet der Server (wie bisher) eine OneSignal-Push-Benachrichtigung
- Solange die App im Hintergrund läuft (Prozess aktiv), fängt `ApplicationClass.kt` diese Benachrichtigung ab und öffnet **`AlertActivity`** — eine Vollbild-Oberfläche mit durchgehendem Alarmton (`res/raw/alert_sound.wav`, wird in Dauerschleife abgespielt) und Vibration
- Ein Klick auf **„Bestellung ansehen"** stoppt den Alarm und öffnet die passende Seite direkt in der App
- Falls der Prozess komplett beendet wurde (sehr selten bei aktiver Nutzung auf einem dauerhaft angeschlossenen Tablet), zeigt OneSignal automatisch eine normale System-Benachrichtigung mit Ton als Rückfallebene

---

## 9. App-Icon anpassen (optional)

Ein einfaches Platzhalter-Icon ist bereits enthalten (`app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`). Um das eigene Logo zu verwenden:
1. In Android Studio: Rechtsklick auf `app` → **New → Image Asset**
2. Eigenes Logo (quadratisches PNG) hochladen → Android generiert automatisch alle benötigten Größen

---

## 10. Beide Rollen auf verschiedenen Geräten

Diese eine App deckt **beide Anwendungsfälle** ab — bei der ersten Öffnung auf jedem Gerät wird einmalig "Restaurant" oder "Fahrer" gewählt und gespeichert. Es muss nur **einmal gebaut/installiert** werden und funktioniert auf beliebig vielen Geräten (Küchen-Tablet, Fahrer-Handys) unabhängig voneinander.
