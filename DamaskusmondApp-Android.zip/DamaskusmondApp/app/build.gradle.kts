plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.damaskusmond.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.damaskusmond.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
    }
}

// Erzwingt eine einheitliche Kotlin-stdlib-Version über alle Abhängigkeiten hinweg,
// damit keine Bibliothek (z.B. OneSignal) versehentlich eine neuere/inkompatible Version zieht.
configurations.all {
    resolutionStrategy {
        force("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // OneSignal Push SDK - siehe https://documentation.onesignal.com/docs/android-sdk-setup
    // Bitte vor dem Bauen auf die neueste Version prüfen: https://mvnrepository.com/artifact/com.onesignal/OneSignal
    implementation("com.onesignal:OneSignal:[5.0.0, 5.99.99]")
}
