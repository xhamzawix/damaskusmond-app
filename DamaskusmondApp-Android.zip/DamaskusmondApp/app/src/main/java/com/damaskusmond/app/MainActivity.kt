package com.damaskusmond.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.onesignal.OneSignal

class MainActivity : AppCompatActivity() {

    // TODO: Bei Bedarf die Basis-URL anpassen, falls sich der Installationspfad ändert
    private val baseUrl = "https://www.damaskusmond.com/orders"

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startMonitorService()

        // Hält den Bildschirm dauerhaft an, solange diese App sichtbar im Vordergrund ist -
        // verhindert, dass das Gerät während des Wartens auf Bestellungen automatisch
        // in den Sperrbildschirm wechselt.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)

        val role = intent.getStringExtra("role")
            ?: getSharedPreferences("damaskusmond", MODE_PRIVATE).getString("role", "restaurant")
            ?: "restaurant"

        webView = findViewById(R.id.webView)
        webView.setBackgroundColor(Color.parseColor("#1a1210"))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WebAppInterface(), "AndroidBridge")

        // Falls die App über einen Alarm-Klick mit einer bestimmten Ziel-URL geöffnet wurde
        val targetUrl = intent.getStringExtra("openUrl")

        val startUrl = when {
            !targetUrl.isNullOrBlank() -> targetUrl
            role == "driver" -> "$baseUrl/driver/index.php"
            else -> "$baseUrl/restaurant/index.php"
        }
        webView.loadUrl(startUrl)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun startMonitorService() {
        val serviceIntent = Intent(this, OrderMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    /**
     * Wird aus der PHP-Seite heraus aufgerufen (siehe restaurant/index.php und driver/index.php),
     * um dem nativen Teil der App die Fahrer-ID mitzuteilen, damit gezielte Push-Benachrichtigungen
     * pro Fahrer funktionieren.
     */
    inner class WebAppInterface {
        @JavascriptInterface
        fun setDriverId(driverId: Int) {
            OneSignal.User.addTag("driver_id", driverId.toString())
        }

        @JavascriptInterface
        fun setRole(role: String) {
            OneSignal.User.addTag("role", role)
        }
    }
}
