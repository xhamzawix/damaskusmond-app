package com.damaskusmond.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground-Service, der die App aktiv hält, damit eingehende Bestellbenachrichtigungen
 * zuverlässig empfangen werden - auch wenn Android sonst versuchen würde, den Prozess
 * im Hintergrund zu beenden, um Akku zu sparen.
 *
 * Zeigt dafür verpflichtend (Android-Systemvorgabe) ein dauerhaftes, unaufdringliches
 * Symbol in der Statusleiste, solange die App aktiv ist.
 */
class OrderMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "damaskusmond_monitor"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("damaskusmond")
            .setContentText("Bereit für neue Bestellungen")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: Android versucht, den Service nach einem erzwungenen Beenden
        // automatisch neu zu starten.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "App-Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Zeigt, dass damaskusmond aktiv auf Bestellungen wartet"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
