package com.damaskusmond.app

import android.app.Application
import android.content.Context
import com.onesignal.OneSignal
import com.onesignal.debug.LogLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Initialisiert OneSignal beim App-Start.
 *
 * Die eigentliche Abfangung der Push-Benachrichtigungen (um stattdessen den
 * Vollbild-Alarm zu starten) übernimmt OrderNotificationServiceExtension.kt -
 * diese funktioniert zuverlässig in JEDEM App-Zustand (Vordergrund, Hintergrund,
 * oder komplett beendete App), im Gegensatz zu einem einfachen Foreground-Listener,
 * der nur reagiert, während die App sichtbar im Vordergrund ist.
 */
class ApplicationClass : Application() {

    companion object {
        const val ONESIGNAL_APP_ID = "12220087-4142-4c7d-98c9-02070a88fdd6"
        lateinit var appContext: Context
    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext

        OneSignal.Debug.logLevel = LogLevel.WARN
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID)

        CoroutineScope(Dispatchers.IO).launch {
            OneSignal.Notifications.requestPermission(false)
        }
    }
}
