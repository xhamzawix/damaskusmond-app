package com.damaskusmond.app

import android.app.Application
import android.content.Intent
import com.onesignal.OneSignal
import com.onesignal.debug.LogLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Initialisiert OneSignal beim App-Start und fängt eingehende Push-Benachrichtigungen ab,
 * um stattdessen den eigenen Vollbild-Alarm (AlertActivity) zu starten.
 *
 * WICHTIG: Die OneSignal App ID unten muss durch die eigene ID ersetzt werden
 * (dieselbe, die bereits für die Web-Push-Integration verwendet wird).
 * Zu finden unter: OneSignal Dashboard -> Settings -> Keys & IDs
 */
class ApplicationClass : Application() {

    companion object {
        // OneSignal App ID (dieselbe wie im Web-Setup)
        const val ONESIGNAL_APP_ID = "12220087-4142-4c7d-98c9-02070a88fdd6"
    }

    override fun onCreate() {
        super.onCreate()

        OneSignal.Debug.logLevel = LogLevel.WARN
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID)

        CoroutineScope(Dispatchers.IO).launch {
            OneSignal.Notifications.requestPermission(false)
        }

        // Solange die App (der Prozess) läuft - auch wenn eine andere App im Vordergrund ist -
        // wird JEDE eingehende Push-Benachrichtigung abgefangen und als Vollbild-Alarm angezeigt,
        // anstatt als normale Benachrichtigung in der Statusleiste.
        OneSignal.Notifications.addForegroundLifecycleListener(object :
            com.onesignal.notifications.INotificationLifecycleListener {
            override fun onWillDisplay(event: com.onesignal.notifications.INotificationWillDisplayEvent) {
                // Standard-Anzeige der Benachrichtigung verhindern
                event.preventDefault()

                val notification = event.notification
                val title = notification.title ?: getString(R.string.new_order_title)
                val body = notification.body ?: ""
                val url = notification.additionalData?.optString("url", "") ?: ""

                val intent = Intent(applicationContext, AlertActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("title", title)
                    putExtra("body", body)
                    putExtra("url", url)
                }
                applicationContext.startActivity(intent)
            }
        })
    }
}
