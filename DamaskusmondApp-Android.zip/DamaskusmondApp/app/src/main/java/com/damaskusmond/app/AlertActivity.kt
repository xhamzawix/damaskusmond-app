package com.damaskusmond.app

import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Vollbild-Bestellalarm - erscheint über jeder anderen App und sogar über dem Sperrbildschirm,
 * mit durchgehendem Ton und Vibration, bis der Mitarbeiter reagiert.
 * Vergleichbar mit dem Verhalten eines eingehenden Anrufs.
 */
class AlertActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Über Sperrbildschirm anzeigen und Bildschirm einschalten
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        setContentView(R.layout.activity_alert)

        val title = intent.getStringExtra("title") ?: getString(R.string.new_order_title)
        val body = intent.getStringExtra("body") ?: ""
        val targetUrl = intent.getStringExtra("url") ?: ""

        findViewById<TextView>(R.id.alertTitle).text = title
        findViewById<TextView>(R.id.alertBody).text = body

        findViewById<Button>(R.id.btnViewOrder).setOnClickListener {
            stopAlert()
            val i = Intent(this, MainActivity::class.java)
            if (targetUrl.isNotBlank()) { i.putExtra("openUrl", targetUrl) }
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(i)
            finish()
        }

        findViewById<Button>(R.id.btnDismiss).setOnClickListener {
            stopAlert()
            finish()
        }

        startAlarmSound()
        startVibration()
    }

    private fun startAlarmSound() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.alert_sound).apply {
                isLooping = true
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                start()
            }
        } catch (e: Exception) {
            // Ton konnte nicht gestartet werden - Vibration läuft trotzdem weiter
        }
    }

    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        val pattern = longArrayOf(0, 800, 400, 800, 400)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopAlert() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
        vibrator?.cancel()
    }

    override fun onDestroy() {
        stopAlert()
        super.onDestroy()
    }
}
