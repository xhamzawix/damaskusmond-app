package com.damaskusmond.app

import android.content.Intent
import androidx.annotation.Keep
import com.onesignal.notifications.INotificationReceivedEvent
import com.onesignal.notifications.INotificationServiceExtension

/**
 * Fängt JEDE eingehende OneSignal Push-Benachrichtigung ab, BEVOR sie angezeigt wird -
 * und zwar zuverlässig unabhängig davon, ob die App gerade im Vordergrund, im
 * Hintergrund (z.B. hinter einer anderen offenen App), oder komplett beendet ist.
 *
 * Muss in AndroidManifest.xml registriert werden (bereits enthalten):
 *   <meta-data android:name="com.onesignal.NotificationServiceExtension"
 *              android:value="com.damaskusmond.app.OrderNotificationServiceExtension" />
 */
@Keep
class OrderNotificationServiceExtension : INotificationServiceExtension {

    override fun onNotificationReceived(event: INotificationReceivedEvent) {
        // Verhindert, dass zusätzlich eine normale System-Benachrichtigung angezeigt wird -
        // stattdessen übernimmt AlertActivity die komplette Anzeige.
        event.preventDefault()

        val notification = event.notification
        val title = notification.title ?: "Neue Bestellung!"
        val body = notification.body ?: ""
        val url = notification.additionalData?.optString("url", "") ?: ""

        val context = ApplicationClass.appContext
        val intent = Intent(context, AlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("title", title)
            putExtra("body", body)
            putExtra("url", url)
        }
        context.startActivity(intent)
    }
}
