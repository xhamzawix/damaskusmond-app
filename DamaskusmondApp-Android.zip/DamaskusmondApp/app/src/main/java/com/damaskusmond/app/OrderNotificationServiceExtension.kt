package com.damaskusmond.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.Keep
import androidx.core.app.NotificationCompat
import com.onesignal.notifications.INotificationReceivedEvent
import com.onesignal.notifications.INotificationServiceExtension

/**
 * Fängt JEDE eingehende OneSignal Push-Benachrichtigung ab und zeigt sie als
 * "Vollbild-Intent"-Benachrichtigung an - der EINZIGE von Android offiziell
 * erlaubte Weg, um zuverlässig eine Vollbild-Oberfläche aus dem Hintergrund heraus
 * zu starten (dieselbe Technik, die Anruf-Apps verwenden).
 *
 * WICHTIG: Ein direkter Aufruf von startActivity() aus dieser Klasse heraus würde
 * von Android 10+ aus Sicherheitsgründen stillschweigend blockiert werden (weder
 * die Vollbild-Anzeige noch überhaupt eine normale Benachrichtigung würde erscheinen).
 * Der Weg über NotificationCompat.Builder().setFullScreenIntent() ist von dieser
 * Einschränkung ausdrücklich ausgenommen.
 */
@Keep
class OrderNotificationServiceExtension : INotificationServiceExtension {

    companion object {
        const val ALERT_CHANNEL_ID = "damaskusmond_order_alert"
    }

    override fun onNotificationReceived(event: INotificationReceivedEvent) {
        // Verhindert die normale Standard-Anzeige von OneSignal -
        // wir zeigen stattdessen unsere eigene Vollbild-Benachrichtigung.
        event.preventDefault()

        val notification = event.notification
        val title = notification.title ?: "Neue Bestellung!"
        val body = notification.body ?: ""
        val url = notification.additionalData?.optString("url", "") ?: ""

        val context = ApplicationClass.appContext
        createChannelIfNeeded(context)

        val fullScreenIntent = Intent(context, AlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("title", title)
            putExtra("body", body)
            putExtra("url", url)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun createChannelIfNeeded(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(ALERT_CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    ALERT_CHANNEL_ID,
                    "Bestellalarm",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Vollbild-Alarm bei neuen Bestellungen"
                    enableVibration(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }
}
