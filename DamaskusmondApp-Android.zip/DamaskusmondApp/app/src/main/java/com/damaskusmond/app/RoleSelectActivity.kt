package com.damaskusmond.app

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.onesignal.OneSignal

class RoleSelectActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("damaskusmond", MODE_PRIVATE)

        val savedRole = prefs.getString("role", null)
        if (savedRole != null) {
            openMain(savedRole)
            return
        }

        setContentView(R.layout.activity_role_select)

        findViewById<android.widget.Button>(R.id.btnRestaurant).setOnClickListener {
            selectRole("restaurant")
        }
        findViewById<android.widget.Button>(R.id.btnDriver).setOnClickListener {
            selectRole("driver")
        }
    }

    private fun selectRole(role: String) {
        prefs.edit().putString("role", role).apply()
        OneSignal.User.addTag("role", role)
        openMain(role)
    }

    private fun openMain(role: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("role", role)
        startActivity(intent)
        finish()
    }
}
