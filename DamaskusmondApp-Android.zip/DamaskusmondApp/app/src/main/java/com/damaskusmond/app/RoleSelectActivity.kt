package com.damaskusmond.app

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.onesignal.OneSignal

class RoleSelectActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startMonitorService()
        requestBatteryOptimizationExemption()
        prefs = getSharedPreferences("damaskusmond", MODE_PRIVATE)

        val savedRole = prefs.getString("role", null)
        if (savedRole != null) {
            openMain(savedRole)
            return
        }

        setContentView(R.layout.activity_role_select)

        findViewById<android.widget.Button>(R.id.btnRestaurant).setOnClickListener {
            selectRole("restaurant")
        }
        findViewById<android.widget.Button>(R.id.btnDriver).setOnClickListener {
            selectRole("driver")
        }
    }

    private fun startMonitorService() {
        val serviceIntent = Intent(this, OrderMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    /**
     * Fragt einmalig die Ausnahme von der Akku-Optimierung an, damit Android
     * die App nicht im Hintergrund beendet und Push-Benachrichtigungen zuverlässig
     * ankommen. Zeigt dafür den Standard-System-Dialog von Android an.
     * Wird automatisch übersprungen, falls die Ausnahme bereits erteilt wurde.
     */
    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return

        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                // Manche Geräte/Hersteller unterstützen diesen Standard-Dialog nicht -
                // in dem Fall bleibt nur der manuelle Weg über die Geräteeinstellungen.
            }
        }
    }

    private fun selectRole(role: String) {
        prefs.edit().putString("role", role).apply()
        OneSignal.User.addTag("role", role)
        openMain(role)
    }

    private fun openMain(role: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("role", role)
        startActivity(intent)
        finish()
    }
}
